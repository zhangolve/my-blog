A Pen created at CodePen.io. You can find this one at http://codepen.io/zhangolve/pen/qZywze.

 

Forked from [Adam](http://codepen.io/ayhaadam/)'s Pen [One Page Scroll JS Demo](http://codepen.io/ayhaadam/pen/bCzum/).